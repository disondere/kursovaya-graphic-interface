﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace QuizApplication
{
    // Класс для хранения данных вопроса
    public class Question
    {
        public string Text { get; set; }
        public List<string> Options { get; set; }
        public int CorrectOptionIndex { get; set; }

        public Question(string text, List<string> options, int correctOptionIndex)
        {
            Text = text;
            Options = options;
            CorrectOptionIndex = correctOptionIndex;
        }
    }

    // Класс для викторины
    public class Quiz
    {
        public string Name { get; set; }
        public List<Question> Questions { get; set; }

        public Quiz(string name)
        {
            Name = name;
            Questions = new List<Question>();
        }

        public void AddQuestion(Question question)
        {
            Questions.Add(question);
        }
    }

    // Менеджер для управления викторинами
    public class QuizManager
    {
        public List<Quiz> Quizzes { get; private set; }

        public QuizManager()
        {
            Quizzes = new List<Quiz>();
        }

        public void SaveToFile(string filePath)
        {
            var json = JsonSerializer.Serialize(Quizzes);
            File.WriteAllText(filePath, json);
        }

        public void LoadFromFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                var json = File.ReadAllText(filePath);
                Quizzes = JsonSerializer.Deserialize<List<Quiz>>(json);
            }
        }

        public void DisplayQuizzes()
        {
            for (int i = 0; i < Quizzes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Quizzes[i].Name}");
            }
        }

        public Quiz SelectQuiz(int index)
        {
            return Quizzes[index];
        }
    }

    // Основной класс для окна приложения
    public partial class MainWindow : Window
    {
        private QuizManager manager = new QuizManager();
        private string filePath = "quizzes.json";

        public MainWindow()
        {
            InitializeComponent();
            manager.LoadFromFile(filePath);
        }

        // Обработчик нажатия на кнопку "View Quizzes"
        private void ViewQuizzesButton_Click(object sender, RoutedEventArgs e)
        {
            manager.DisplayQuizzes();
        }

        // Обработчик нажатия на кнопку "Take a Quiz"
        private void TakeQuizButton_Click(object sender, RoutedEventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Введите номер викторины: ");
            int quizIndex;
            if (int.TryParse(input, out quizIndex) && quizIndex >= 1 && quizIndex <= manager.Quizzes.Count)
            {
                StartQuiz(manager.Quizzes[quizIndex - 1]);
            }
            else
            {
                MessageBox.Show("Неверный номер викторины.");
            }
        }

        // Обработчик нажатия на кнопку "Create a Quiz"
        private void CreateQuizButton_Click(object sender, RoutedEventArgs e)
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox("Введите название новой викторины: ");
            Quiz quiz = new Quiz(name);

            while (true)
            {
                string questionText = Microsoft.VisualBasic.Interaction.InputBox("Введите текст вопроса (или пустую строку для завершения): ");
                if (string.IsNullOrEmpty(questionText)) break;

                List<string> options = new List<string>();
                for (int i = 0; i < 4; i++)
                {
                    string option = Microsoft.VisualBasic.Interaction.InputBox($"Введите вариант ответа {i + 1}: ");
                    options.Add(option);
                }

                string correctOptionInput = Microsoft.VisualBasic.Interaction.InputBox("Введите номер правильного ответа (1-4): ");
                int correctOption;
                if (int.TryParse(correctOptionInput, out correctOption) && correctOption >= 1 && correctOption <= 4)
                {
                    quiz.AddQuestion(new Question(questionText, options, correctOption - 1));
                }
                else
                {
                    MessageBox.Show("Неверный номер правильного ответа.");
                }
            }

            manager.Quizzes.Add(quiz);
            manager.SaveToFile(filePath);
        }

        // Метод для старта викторины
        private void StartQuiz(Quiz quiz)
        {
            int correctAnswers = 0;

            foreach (var question in quiz.Questions)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox(question.Text + "\n" + string.Join("\n", question.Options) + "\nВаш ответ: ");
                int answer;
                if (int.TryParse(input, out answer) && answer >= 1 && answer <= 4)
                {
                    if (answer - 1 == question.CorrectOptionIndex)
                    {
                        MessageBox.Show("Правильно!");
                        correctAnswers++;
                    }
                    else
                    {
                        MessageBox.Show($"Неправильно! Правильный ответ: {question.Options[question.CorrectOptionIndex]}");
                    }
                }
                else
                {
                    MessageBox.Show("Неверный выбор ответа.");
                }
            }

            MessageBox.Show($"Викторина завершена. Правильных ответов: {correctAnswers} из {quiz.Questions.Count}.");
        }
    }
}
